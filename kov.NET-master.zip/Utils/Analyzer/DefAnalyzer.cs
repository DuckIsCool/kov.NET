﻿namespace kov.NET.Utils.Analyzer
{
	public abstract class DefAnalyzer
	{
		public abstract bool Execute(object context);
	}
}